import { NotificationPage } from '../modal/notification/notification.page';
import { UtilService } from "../services/util.service";
import { ApiService } from "../services/api.service";
import { Component, OnInit, ViewChild, ElementRef, NgZone } from "@angular/core";
import { NavController } from "@ionic/angular";
import {
  NativeGeocoder,
  NativeGeocoderResult,
  NativeGeocoderOptions,
} from "@ionic-native/native-geocoder/ngx";
import { Geolocation } from "@ionic-native/geolocation/ngx";

import { MapsAPILoader, AgmCoreModule } from '@agm/core';
import { CartService } from "src/app/services/cart.service";
import { ActivatedRoute, Router } from "@angular/router";
import { ModalController, AlertController } from '@ionic/angular';


// declare var google: any;

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  @ViewChild('search')
  public searchElementRef: ElementRef;
  // google maps zoom level
  address: string;
  zoom: number = 13;
  zoomControl: false
  data: any = [];
  err: any;
  // initial center position for the map
  lat: number = 28.6196;
  lng: number = 77.0550;

  private geoCoder;

  constructor(
    private router: Router,
    private navCtrl: NavController,
    private nativeGeocoder: NativeGeocoder,
    private api: ApiService,
    private util: UtilService,
    private geolocation: Geolocation,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private cart: CartService,
    private route: ActivatedRoute,

  ) {
    // this.route.queryParams.subscribe((res)=>{
    //   // debugger
    //   if(res.from='modal'){
    //     debugger
    //      this.getAddress(res.lat, res.lng);
    //   }
    //   // debugger
    // })

  }

  ngOnInit() {
    // this.lat=this.cart.coords.lat;
    // this.lng= this.cart.coords.lng;

    this.mapsAPILoader.load().then(() => {
      this.setCurrentLocation();
      this.geoCoder = new google.maps.Geocoder;
      // var myOptions = {
      //   zoom: 15,
      //   mapTypeControl: false,
      //   draggable: false,
      //   scaleControl: false,
      //   scrollwheel: false,
      //   navigationControl: false,
      //   streetViewControl: false,
      //   mapTypeId: google.maps.MapTypeId.ROADMAP
      // };

      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement,);
      autocomplete.addListener("place_changed", (res) => {
        console.log(res);
        debugger
        this.ngZone.run(() => {
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();

          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          this.lat = place.geometry.location.lat();
          this.lng = place.geometry.location.lng();
          this.zoom = 14;
          this.getAddress(place.geometry.location.lat(), place.geometry.location.lng());
        });
      });
    });
  }

  setCurrentLocation() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        // debugger
        this.lat = position.coords.latitude;
        this.lng = position.coords.longitude;
        this.zoom = 14;
        this.zoomControl = false
        this.getAddress(this.lat, this.lng);
      });
    }
  }

  markerDragEnd($event) {
    // debugger
    console.log($event);
    this.lat = $event.coords.lat;
    this.lng = $event.coords.lng;
    this.getAddress(this.lat, this.lng);
  }

  getAddress(latitude, longitude) {
    this.geoCoder.geocode({ 'location': { lat: latitude, lng: longitude } }, (results, status) => {
      if (status === 'OK') {
        if (results[0]) {
          this.zoom = 14;
          // this.cart.googleAddress = results[0].formatted_address;
          this.address = results[0].formatted_address;
        } else {
          window.alert('No results found');
        }
      } else {
        window.alert('Geocoder failed due to: ' + status);
      }

    });
  }

  getLocationByNotification() {
    this.lat = this.cart.coords.lat;
    this.lng = this.cart.coords.lng;
    this.geoCoder = new google.maps.Geocoder;
    this.geoCoder.geocode({ 'location': { lat: this.lat, lng: this.lng } }, (results, status) => {
      if (status === 'OK') {
        if (results[0]) {
          this.zoom = 14;
          // this.cart.googleAddress = results[0].formatted_address;
          this.address = results[0].formatted_address;
          // this.lat = parseFloat(latitude);
          // this.lng = parseFloat(longitude);
          debugger
        } else {
          window.alert('No results found');
        }
      } else {
        window.alert('Geocoder failed due to: ' + status);
      }

    });
  }

  // getaddress() {
  //   const x = this.cart.googleAddress === '' ? 'Please add your Location...' : this.cart.googleAddress;
  //   return x;
  // }


}
